from collections import deque
import sys

graph=[]
method=sys.argv[1]
filename=sys.argv[2]
with open(filename,"r") as file_example:
    for line in file_example:
        l=line.split()
        l[0]=int(l[0])
        l[1]=int(l[1])
        graph.append(l)

#μέθοδος που βρίσκει το λεξικό γειτνίασης του γράφου
def create_adjacency_dictionary(datalist):
    diction={}
    for data in datalist:
        u,n=data
        if u not in diction:
            diction[u]=[]
        diction[u].append(n)
        if n not in diction:
            diction[n]=[]
        diction[n].append(u)
    return diction

#μέθοδος που φτιάνχει τη λίστα που περιέχει το σύνολο με τους κόμβους
def create_graph_nodes(adj_dic:dict):
    nodes=set(adj_dic.keys())
    node_list=list()
    node_list.append(nodes)
    return node_list
    

#μέθοδος που βρίσκει την λεξικογραφική κατά πλάτος αναζήτηση
def lexbfs():
    adjacency_dictionary1=create_adjacency_dictionary(graph)
    graph_nodes1=create_graph_nodes(adjacency_dictionary1)
    order=[]
    while len(graph_nodes1)>0:
        checkingelement_index=0
        counter1=0
        #εύρεση στοιχείο αφαίρεσης απότη λίστα
        for i in range(len(graph_nodes1)):
            entering_num=min(graph_nodes1[i])
            for j in graph_nodes1[i].copy():
                if counter1==0 and j==entering_num :
                    checkingelement=j
                    checkingelement_index=i
            counter1=counter1+1
        #διαγραφή στοιχείου
        graph_nodes1[checkingelement_index].discard(checkingelement)
        #αφαίρεση συνόλου σε περίπτωση που είναι άδεια
        if len(graph_nodes1[checkingelement_index])==0:
            graph_nodes1.remove(graph_nodes1[checkingelement_index])
        order.append(checkingelement)
        #εύρεση γειτόνων από το λεξικό γειτνίασης
        neighbors=adjacency_dictionary1.get(checkingelement)
        new_list=list()
        #ευρεση για γειτονικών και όχι κόμβων του στοιχείου που ελέγχουμε και δημιουργία νέας λίστας συνόλως
        for f in range(len(graph_nodes1)):
            set_of_neighbors=set()
            set_of_not_neighbors=set()
            for j in graph_nodes1[f]:
                    if j in neighbors:
                        set_of_neighbors.add(j)
                    if j not in neighbors:
                        set_of_not_neighbors.add(j)
            if len(set_of_neighbors)>0:
                new_list.append(set_of_neighbors)
            if len(set_of_not_neighbors)>0:    
                new_list.append(set_of_not_neighbors)
        graph_nodes1=new_list

    return order
 
#εύρεση πρώτου γείτονα από το σύνολο γειτόνων του κόμβου
def find_first_neighbor(checking_set):
    checking_set=list(checking_set)
    reverse_checking_set=checking_set.copy()
    reverse_checking_set.reverse()
    if reverse_checking_set!=[]:    
        returning_element=reverse_checking_set[0]
    else:
        returning_element=set()
    return returning_element

#εύρεση γειτόνων που έπονται του στοιχείου ελέγχου
def find_u_neighbors(checking_element,adj_dic,rev_lexbfs):
    first_set=adj_dic[checking_element]
    returning_set=set()
    for i in range(rev_lexbfs.index(checking_element)+1,len(rev_lexbfs)):
        if rev_lexbfs[i] in first_set:
            returning_set.add(rev_lexbfs[i])
    return returning_set

#μέθοδος εξέτασης του γράφου για το αν είναι χορδικός
def chordal():
    lexbfsorder=lexbfs()
    reversed_lexbfs=lexbfsorder.copy()
    reversed_lexbfs.reverse()
    adjacency_dictionary2=create_adjacency_dictionary(graph)
    flag=0
    for i in reversed_lexbfs:
        u_neighbors=find_u_neighbors(i,adjacency_dictionary2,reversed_lexbfs)
        first_neighbor=find_first_neighbor(u_neighbors)
        #αφαίρεση πρώτου γείτονα
        u_neighbors.discard(first_neighbor)
        if first_neighbor!=set():
            #έυρεση γειτόνων πρώτου γείτονα το κόμβου u
            v_neighbors=set(adjacency_dictionary2.get(first_neighbor))
        else:
            v_neighbors=set()
            #έλεχγος αν οι γείτονες του u ειναι υποσύνολο του n
        if u_neighbors.issubset(v_neighbors):
            flag=flag+1
    if flag==len(reversed_lexbfs):
        result=True
    else:
        result=False
    return result
         
#εύρεση μετασχημέτένου λεξικού μετά την αφαίρεση του στοιχείου ελέγχου και των γειτόνων του
def create_altered_adjacency_dictionary(element,dictionary:dict):
    test_dic=dictionary.copy()
    neighbors=test_dic.get(element)
    for i in range(len(dictionary)):
        if i==element:
            del test_dic[i]
        if i in neighbors:
            del test_dic[i]
        if i not in neighbors and i!=element:
            list_in_dict=list()
            for j in dictionary[i]:
                    if j not in neighbors:
                        list_in_dict.append(j)
            test_dic[i]=list_in_dict                
    return test_dic

#εφαρμογή κατα πλάτους αναζήτησης 
def bfs(dictionary):
    visited=list()
    comps=list()
    for graph_node in dictionary:
        if graph_node not in visited:
            comp=list()
            tail=deque([graph_node])
            visited.append(graph_node)
            while tail:
                this_graph_node=tail.popleft()
                comp.append(this_graph_node)
                for n_node in dictionary[this_graph_node]:
                    if n_node not in visited:
                        tail.append(n_node)
                        visited.append(n_node)
            comps.append(comp)
    return comps

#έλεγχος ανεξαρτησίας των τριών κόμβων που ελέγχονται
def checking_independency(i,j,z,dictionary:dict):
    result=True
    if j in dictionary[i] or z in dictionary[i] or z in dictionary[j]:
        result=False
    
    return result

#μέθοδος που ελέχγει για το αν ο γράφος που εξετάζεται ειναι διαστημάτων
def interval(this_graph):
    adjacency_dictionary3=create_adjacency_dictionary(this_graph)
    c=[]
    #δημιουργία πίνακα c και συμπληρωσή του με μηδενικά
    for i in range(len(adjacency_dictionary3)):
        list_of_zeros=list()
        for i in range(len(adjacency_dictionary3)):
            list_of_zeros.append(0)
        c.append(list_of_zeros)

    #εύρεση συνιστώσων γράφων και εισαγωγή τουσ στον πίνακα c
    for i in range(len(c)):
        list_of_components=list()
        altered_dictionary=create_altered_adjacency_dictionary(i,adjacency_dictionary3)
        list_of_components=bfs(altered_dictionary)
        for j in range(len(list_of_components)):
            for y in range(len(c)):
                if y in list_of_components[j]:
                    c[i][y]=list_of_components[j]

    #εφαρμογή κριτηρίων εξακρίβωσης για το αν ο γράφος ειναι διαστημάτων

    result=True
    for u in adjacency_dictionary3:
        for v in adjacency_dictionary3[u]:
            for w in adjacency_dictionary3[v]:
                    check=checking_independency(u,v,w,adjacency_dictionary3)
                    if w not in adjacency_dictionary3[u] and check==True:
                        if c[u][v]==c[u][w] or c[v][u]==c[v][w] or c[w][u]==c[w][v]:
                            result=False
                                    
    return result

if method=="lexbfs":
    bfs_order=lexbfs()
    print(bfs_order)
elif method=="chordal":
    chordal_result=chordal()
    print(chordal_result)
elif method=="interval":
    interval_result=interval(graph)
    print(interval_result)

    


    


    
    
